/**
 * 
 */
/**
 * @author internous
 *
 */
package com.internousdev.template.dao;